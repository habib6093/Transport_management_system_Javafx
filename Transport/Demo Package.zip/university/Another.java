package university;

public class Another{
	public static void main(String ar[]){
		System.out.println("Another main()");
	}
	public void hello(){
		System.out.println("Hello from Another");
	}
}